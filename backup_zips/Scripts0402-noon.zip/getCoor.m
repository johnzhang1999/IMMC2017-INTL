function [lat,lon] = getCoor(city)
%Google Geocoding API
%req = strcat('https://maps.googleapis.com/maps/api/geocode/json?address=',city,'&key=AIzaSyCU9ICU3_2GI1ClRYWgTivPhpIC3-I9E4c');
req = strcat('http://www.datasciencetoolkit.org/maps/api/geocode/json?sensor=false&address=',city)
res = webread(req);
lat = res.results.geometry.location.lat;
lon = res.results.geometry.location.lng;