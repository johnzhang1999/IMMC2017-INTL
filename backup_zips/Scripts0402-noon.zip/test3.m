f=@(x)(2*x);
f2=@(x)f(x)-2;
solve(f2,0)