function y = f1( x )
if x<0
    y=-x;
else
    y=x;
end
end


