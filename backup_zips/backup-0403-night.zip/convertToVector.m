PriceVec=Price';
PriceVec=PriceVec(:);
DistanceVec=Distance';
DistanceVec=DistanceVec(:);